class NetInterface:
    name = None
    actual_metric = None
    desired_metric = None
    metric_factor = None
    status = None
    connection_status = None
    if_type = None
    priority = None
    